import torch
import torch.nn as nn
from torchvision import models
from tqdm import tqdm

class VGG16Regressor(nn.Module):
    """
    VGG16-based regression model.
    Uses pretrained convolutional backbone, replaces classifier with regression head.
    """

    def __init__(self, num_outputs=3, pretrained=False, fine_tune=False):
        super(VGG16Regressor, self).__init__()

        # Load VGG16 backbone
        self.vgg = models.vgg16(pretrained=pretrained)

        # Optionally freeze convolutional feature extractor
        if fine_tune:
            for param in self.vgg.features.parameters():
                param.requires_grad = False

        # Replace classifier with custom regression head
        in_features = self.vgg.classifier[0].in_features
        self.vgg.classifier = nn.Sequential(
            nn.Linear(in_features, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_outputs)   # continuous outputs
        )

    def forward(self, x):
        return self.vgg(x)
    
if __name__ == "__main__":
    # Test the model
    model = VGG16Regressor(num_outputs=3, pretrained=False, fine_tune=False)

    # count parameters
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"VGG16: total parameters: {total_params}")

    # Example input
    dummy_input = torch.randn(2, 3, 224, 224)  # batch_size=2, channels=3, H=224, W=224
    output = model(dummy_input)

    print(f"Input shape: {dummy_input.shape}")
    print(f"Output shape: {output.shape}")  # Should be (2, 3)
    print(f"Output: {output}")
