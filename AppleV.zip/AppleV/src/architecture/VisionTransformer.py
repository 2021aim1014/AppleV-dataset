import torch
import torch.nn as nn
from transformers import ViTModel, ViTConfig
from tqdm import tqdm

class VisionTransformer(nn.Module):
    def __init__(self, num_outputs=3, pretrained=False, num_hidden_layers=12):
        super(VisionTransformer, self).__init__()

        # Use Hugging Face ViT (more stable)
        if pretrained:
            self.vit = ViTModel.from_pretrained('google/vit-base-patch16-224')
            # fix the feature extractor layers
            for param in self.vit.parameters():
                param.requires_grad = False
            pass
        else:
            config = ViTConfig(
                image_size=224,
                patch_size=16,
                num_channels=3,
                hidden_size=768,
                num_hidden_layers=num_hidden_layers,
                num_attention_heads=12
            )
            self.vit = ViTModel(config)
        
        # Regression head
        self.regressor = nn.Sequential(
            nn.LayerNorm(768),
            nn.Linear(768, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, num_outputs)
        )
        
    def forward(self, x):
        # ViT forward pass - use [CLS] token for regression
        outputs = self.vit(x)
        cls_output = outputs.last_hidden_state[:, 0, :]  # [CLS] token
        
        return self.regressor(cls_output)
    
    
if __name__ == "__main__":
    # Test the model
    for i in range(12):
        model = VisionTransformer(num_outputs=3, pretrained=False, num_hidden_layers=i+1)
        
        # count parameters
        total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"Vision Transformer: Hidden layer: {i+1} total parameters: {total_params}")

    # Example input
    dummy_input = torch.randn(2, 3, 224, 224)  # batch_size=2, channels=3, H=224, W=224
    output = model(dummy_input)

    print(f"Input shape: {dummy_input.shape}")
    print(f"Output shape: {output.shape}")  # Should be (2, 3)
    print(f"Output: {output}")