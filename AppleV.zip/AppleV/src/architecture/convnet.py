import torch
import torch.nn as nn
import timm

class ConvNeXt(nn.Module):
    def __init__(self, num_outputs=3, pretrained=False, requires_grad=True):
        super(ConvNeXt, self).__init__()

        self.backbone = timm.create_model('convnext_base', pretrained=pretrained, num_classes=0)
        for param in self.backbone.parameters():
            param.requires_grad = requires_grad

        in_features = self.backbone.num_features
        self.regressor = nn.Sequential(
            nn.LayerNorm(in_features),
            nn.Linear(in_features, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, num_outputs)
        )

    def forward(self, x):
        feats = self.backbone(x)  # global pooled features
        return self.regressor(feats)
