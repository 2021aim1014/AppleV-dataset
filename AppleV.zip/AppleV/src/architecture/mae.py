import torch
import torch.nn as nn
from transformers import ViTMAEModel, ViTMAEConfig

class MAETransformer(nn.Module):
    def __init__(self, num_outputs=3, pretrained=True):
        super(MAETransformer, self).__init__()

        if pretrained:
            self.mae = ViTMAEModel.from_pretrained('facebook/vit-mae-base')
            for param in self.mae.parameters():
                param.requires_grad = False
        else:
            config = ViTMAEConfig(
                image_size=224,
                patch_size=16,
                hidden_size=768,
                num_hidden_layers=12,
                num_attention_heads=12,
                intermediate_size=3072
            )
            self.mae = ViTMAEModel(config)

        hidden_dim = self.mae.config.hidden_size

        self.regressor = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 512),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(512, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, num_outputs)
        )

    def forward(self, x):
        outputs = self.mae(x)
        cls_output = outputs.last_hidden_state[:, 0, :]
        return self.regressor(cls_output)
