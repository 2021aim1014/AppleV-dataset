import torch
import torch.nn as nn
from transformers import SwinModel, SwinConfig
from tqdm import tqdm

class SwinTransformer(nn.Module):
    def __init__(self, num_outputs=3, pretrained=False):
        super(SwinTransformer, self).__init__()

        if pretrained:
            self.swin = SwinModel.from_pretrained('microsoft/swin-base-patch4-window7-224')
            for param in self.swin.parameters():
                param.requires_grad = False
        else:
            config = SwinConfig(
                image_size=224,
                patch_size=4,
                num_channels=3,
                embed_dim=128,
                depths=[1, 1, 1, 1],
                num_heads=[4, 8, 16, 32]
            )
            self.swin = SwinModel(config)

        hidden_dim = self.swin.config.hidden_size

        self.regressor = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, 128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, num_outputs)
        )

    def forward(self, x):
        outputs = self.swin(x)
        cls_output = outputs.last_hidden_state[:, 0, :]  # CLS token
        return self.regressor(cls_output)


if __name__ == "__main__":
    # Test various configurations
    model = SwinTransformer(num_outputs=3, pretrained=False)
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Swin Transformer Total trainable params: {total_params/1e6:.2f}M")

    # Example input test
    dummy_input = torch.randn(2, 3, 224, 224)
    output = model(dummy_input)

    print(f"\nInput shape: {dummy_input.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Output sample: {output}")
