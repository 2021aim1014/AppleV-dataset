import torch
import torch.nn as nn
from torchvision import models

class EfficientNetRegressor(nn.Module):
    """
    EfficientNet-based regression model.
    Supports versions: efficientnet_b0 ... efficientnet_b7 (from torchvision >= 0.13).
    """

    def __init__(self, num_outputs=3, backbone='efficientnet_b0', pretrained=True, freeze_backbone=True):
        super(EfficientNetRegressor, self).__init__()

        assert backbone in [
            'efficientnet_b0', 'efficientnet_b1', 'efficientnet_b2',
            'efficientnet_b3', 'efficientnet_b4', 'efficientnet_b5',
            'efficientnet_b6', 'efficientnet_b7'
        ], "Invalid EfficientNet backbone name."

        # Load pretrained model
        self.backbone = getattr(models, backbone)(pretrained=pretrained)

        # Optionally freeze backbone
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False

        # Get input features of the classification head
        in_features = self.backbone.classifier[1].in_features if isinstance(self.backbone.classifier, nn.Sequential) else self.backbone.classifier.in_features

        # Replace classifier with regression head
        self.backbone.classifier = nn.Sequential(
            nn.Linear(in_features, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(128, num_outputs)
        )

    def forward(self, x):
        return self.backbone(x)
