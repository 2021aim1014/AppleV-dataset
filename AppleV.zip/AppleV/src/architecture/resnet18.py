import torch
import torch.nn as nn
from torchvision import models

class ResNetRegressor(nn.Module):
    """
    Generic ResNet-based regression model.
    Supports ResNet18, 34, 50, 101, 152.
    """

    def __init__(self, num_outputs=3, backbone='resnet18', pretrained=False, freeze_backbone=False):
        super(ResNetRegressor, self).__init__()

        # Load chosen ResNet backbone
        assert backbone in ['resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152'], \
            "Invalid backbone; choose from resnet18/34/50/101/152"

        self.backbone = getattr(models, backbone)(pretrained=pretrained)

        # Optionally freeze convolutional layers
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False

        # Replace final fully connected (fc) layer with custom regression head
        in_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Sequential(
            nn.Linear(in_features, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(128, num_outputs)
        )

    def forward(self, x):
        return self.backbone(x)
